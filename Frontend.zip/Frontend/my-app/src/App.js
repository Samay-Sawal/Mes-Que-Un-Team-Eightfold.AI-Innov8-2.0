import React, { useState } from "react";
import Navbar from "./components/Navbar";
import ProfileTable from "./components/ProfileTable";

const App = () => {
  const [filterText, setFilterText] = useState("");
  const [selectedDomain, setSelectedDomain] = useState("");
  const [selectedDomains, setSelectedDomains] = useState([]);

  const handleDomainChange = (newDomains) => {
    setSelectedDomains(newDomains);
  };

  // const profiles = [
  //   { id: 1, name: "John Doe", email: "john@example.com" },
  //   { id: 2, name: "Jane Smith", email: "jane@test.com" },
  //   { id: 3, name: "Alice Johnson", email: "alice@example.com" },
  //   { id: 4, name: "Michael Brown", email: "michael@example.org" },
  // ];

  return (
    <div>
      <Navbar
        filterText={filterText}
        onFilterChange={setFilterText}
        selectedDomain={selectedDomain}
        onDomainChange={setSelectedDomain}
        selectedDomains={selectedDomains}
        // onDomainChange={handleDomainChange}
      />
      <div style={{ margin: "20px" }}>
        <ProfileTable
          // profiles={profiles}
          filterText={filterText}
          selectedDomain={selectedDomain}
        />
      </div>
    </div>
  );
};

export default App;