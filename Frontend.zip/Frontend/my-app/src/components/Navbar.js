import React from "react";

const Navbar = ({ selectedDomains, onDomainChange }) => {
//   const domains = [
//     { name: "Consultancy", iconClass: "fas fa-briefcase" },
//     { name: "Finance", iconClass: "fas fa-dollar-sign" },
//     { name: "Human Resource", iconClass: "fas fa-users" },
//     { name: "Management team", iconClass: "fas fa-chart-line" },
//     { name: "Supporting team", iconClass: "fas fa-hands-helping" },
//     { name: "Teacher", iconClass: "fas fa-chalkboard-teacher" },
//     { name: "Tech Team", iconClass: "fas fa-laptop-code" },
//   ];

//   const handleDomainClick = (domain) => {
//     const newSelectedDomains = selectedDomains.includes(domain)
//       ? selectedDomains.filter((d) => d !== domain) // Remove domain if already selected
//       : [...selectedDomains, domain]; // Add domain if not selected

//     onDomainChange(newSelectedDomains); // Update parent component with the new domain selection
//   };

  return (
    <nav style={{ padding: "10px", background: "#f8f9fa", marginBottom: "20px", display: "flex", justifyContent: "space-between" }}>
      {/* <div>
        <h2>Profile Directory</h2>
      </div> */}
      {/* <div style={{ display: "flex", gap: "10px" }}>
        {domains.map((domain) => (
          <button
            key={domain.name}
            onClick={() => handleDomainClick(domain.name)}
            style={{
              padding: "10px",
              backgroundColor: selectedDomains.includes(domain.name) ? "#007bff" : "#f4f4f4",
              color: selectedDomains.includes(domain.name) ? "white" : "black",
              border: "none",
              cursor: "pointer",
              borderRadius: "50%",
            }}
            title={domain.name}
          >
            <i className={domain.iconClass} style={{ fontSize: "20px" }}></i>
          </button>
        ))}
      </div> */}
    </nav>
  );
};

export default Navbar;
