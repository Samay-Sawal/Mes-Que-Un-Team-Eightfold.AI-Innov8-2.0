import React, { useEffect, useState } from 'react';
import Papa from 'papaparse';

const ProfileTable = () => {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [isCompareMode, setIsCompareMode] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All'); // State to track selected category
  const [keyword, setKeyword] = useState(''); // State for keyword input
  const columnsToShow = ['fraud_score_updated_normalized','ID', 'Custom Influence Score', 'Domain', 'Parsed_Resume', 'profile_score_updated_normalized', 'updated_score'];

  // Fetch and parse the CSV
  const fetchCSV = async () => {
    const response = await fetch('/Influence_Scores_with_Concatenated_Resumes.csv'); // Adjust path if necessary
    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    const result = await reader.read();
    const csvData = decoder.decode(result.value);

    Papa.parse(csvData, {
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        const filteredData = result.data.map((row) => {
          let filteredRow = {};
          columnsToShow.forEach((col) => {
            filteredRow[col] = row[col];
          });
          return filteredRow;
        });
        setData(filteredData);
        setFilteredData(filteredData); // Initialize with full data
      },
      error: (error) => {
        console.error('Error parsing CSV file', error);
      },
    });
  };

  useEffect(() => {
    fetchCSV();
  }, []);

  // Handle checkbox selection
  const handleRowSelect = (id) => {
    setSelectedRows((prevSelected) =>
      prevSelected.includes(id)
        ? prevSelected.filter((rowId) => rowId !== id)
        : [...prevSelected, id]
    );
  };

  // Handle category filter and store selected category
  const filterByCategory = (category) => {
    setSelectedCategory(category); // Track the selected category
    if (category === 'All') {
      setFilteredData(data); // Show all if "All" is selected
    } else {
      setFilteredData(data.filter((row) => row.Domain === category));
    }
  };

  // Handle keyword input and filter rows
  const handleKeywordChange = (event) => {
    const value = event.target.value;
    setKeyword(value);
    // Filter based on keyword input
    if (value) {
      const keywordFilteredData = data.filter((row) =>
        row.Parsed_Resume && row.Parsed_Resume.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredData(keywordFilteredData);
    } else {
      // If no keyword is entered, reset the filtered data
      setFilteredData(data);
    }
  };

  // Filter data to show only selected rows in compare mode
  const displayedData = isCompareMode
    ? filteredData.filter((row) => selectedRows.includes(row.ID))
    : filteredData;

  return (
    <div>
      <h1 style={{"textAlign":"center", fontSize:'50px'}}>SATYA HR Dashboard</h1>
      <div style={{"display":"flex", "justify-content": "space-around", marginBottom:"20px", alignItems:"center"}}>
      <div style={{"width": "20%", "height": "auto"}}>
            <img style={{"width": "100%", "height": "auto"}} src={`${process.env.PUBLIC_URL}/images/total.jpeg`}></img>
        </div>
        <div style={{"width": "40%", "height": "auto"}}>
            <img style={{"width": "100%", "height": "auto"}} src={`${process.env.PUBLIC_URL}/images/image.jpeg`}></img>
        </div>
        <div style={{"width": "20.33%", "height": "auto"}}>
            <img style={{"width": "100%", "height": "auto"}} src={`${process.env.PUBLIC_URL}/images/stats.jpeg`}></img>
        </div>

        {/* <div style={{"width": "33.33%", "height": "100%", "backgroundColor":"greenyellow",alignItems: "center"}}>
            {/* <img style={{"width": "100%", "height": "auto"}} src={`${process.env.PUBLIC_URL}/images/image.jpeg`}></img> */}
            {/* <h3 style={{textAlign:'center', alignItems:"center"}}>300+</h3>
        </div> */} 
      </div>

      

      {/* Icons for Category Filter with Text */}
      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        {/* Existing category filters */}
        <div
          onClick={() => filterByCategory('All')}
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            border: '1px solid #ddd',
            padding: '10px',
            borderRadius: '5px',
            backgroundColor: selectedCategory === 'All' ? 'yellow' : 'white',
          }}
        >
          <i className="fas fa-undo-alt" style={{ fontSize: '20px', marginRight: '5px' }}></i>
          <span>All</span>
        </div>

        <div
          onClick={() => filterByCategory('Tech Team')}
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            border: '1px solid #ddd',
            padding: '10px',
            borderRadius: '5px',
            backgroundColor: selectedCategory === 'Tech Team' ? 'yellow' : 'white', // Highlight selected category
          }}
        >
          <i className="fas fa-users" style={{ fontSize: '20px', marginRight: '5px' }}></i>
          <span>Tech Team</span>
        </div>

        <div
          onClick={() => filterByCategory('Finance')}
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            border: '1px solid #ddd',
            padding: '10px',
            borderRadius: '5px',
            backgroundColor: selectedCategory === 'Finance' ? 'yellow' : 'white',
          }}
        >
          <i className="fas fa-briefcase" style={{ fontSize: '20px', marginRight: '5px' }}></i>
          <span>Finance</span>
        </div>

        <div
          onClick={() => filterByCategory('Management Team')}
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            border: '1px solid #ddd',
            padding: '10px',
            borderRadius: '5px',
            backgroundColor: selectedCategory === 'Management Team' ? 'yellow' : 'white',
          }}
        >
          <i className="fas fa-user-tie" style={{ fontSize: '20px', marginRight: '5px' }}></i>
          <span>Management Team</span>
        </div>

        

        {/* Additional categories */}
        <div
          onClick={() => filterByCategory('Consultancy')}
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            border: '1px solid #ddd',
            padding: '10px',
            borderRadius: '5px',
            backgroundColor: selectedCategory === 'Consultancy' ? 'yellow' : 'white',
          }}
        >
          <i className="fas fa-handshake" style={{ fontSize: '20px', marginRight: '5px' }}></i>
          <span>Consultancy</span>
        </div>

        <div
          onClick={() => filterByCategory('Human Resource (Recruiting Team)')}
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            border: '1px solid #ddd',
            padding: '10px',
            borderRadius: '5px',
            backgroundColor: selectedCategory === 'Human Resource (Recruiting Team)' ? 'yellow' : 'white',
          }}
        >
          <i className="fas fa-user-friends" style={{ fontSize: '20px', marginRight: '5px' }}></i>
          <span>Human Resource</span>
        </div>

        <div
          onClick={() => filterByCategory('Supporting Team')}
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            border: '1px solid #ddd',
            padding: '10px',
            borderRadius: '5px',
            backgroundColor: selectedCategory === 'Supporting Team' ? 'yellow' : 'white',
          }}
        >
          <i className="fas fa-hands-helping" style={{ fontSize: '20px', marginRight: '5px' }}></i>
          <span>Supporting Team</span>
        </div>

        <div
          onClick={() => filterByCategory('Teacher')}
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            border: '1px solid #ddd',
            padding: '10px',
            borderRadius: '5px',
            backgroundColor: selectedCategory === 'Teacher' ? 'yellow' : 'white',
          }}
        >
          <i className="fas fa-chalkboard-teacher" style={{ fontSize: '20px', marginRight: '5px' }}></i>
          <span>Teacher</span>
        </div>
      </div>

      {/* Keyword Input */}
      <input
        type="text"
        value={keyword}
        onChange={handleKeywordChange}
        placeholder="Enter keyword to search..."
        style={{ marginBottom: '20px', padding: '10px', width: '300px', marginRight:'10px' }}
      />

      {/* Compare Button */}
      <button style={{marginBottom: '20px', padding: '10px', width: '300px'}}onClick={() => setIsCompareMode(true)} disabled={selectedRows.length === 0}>
        Compare
      </button>

      {/* Reset Compare Button */}
      {isCompareMode && (
        <button style={{ marginBottom: '20px', padding: '10px', width: '300px', marginRight:'10px', marginLeft: '10px' }} onClick={() => setIsCompareMode(false)}>
          Show All
        </button>
      )}


<table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
  <thead>
    <tr style={{ background: '#343a40', color: 'white', textAlign: 'center' }}>
      <th style={{ padding: '10px', border: '1px solid #ddd' }}>Select</th>
      <th style={{ padding: '10px', border: '1px solid #ddd' }}>ID</th>
      <th style={{ padding: '10px', border: '1px solid #ddd' }}>Influence Score</th>
      <th style={{ padding: '10px', border: '1px solid #ddd' }}>Fraud Score</th>
      <th style={{ padding: '10px', border: '1px solid #ddd' }}>Profile Score</th>
      <th style={{ padding: '10px', border: '1px solid #ddd' }}>Satya's Score</th>
      <th style={{ padding: '10px', border: '1px solid #ddd' }}>Category</th>
      <th style={{ padding: '10px', border: '1px solid #ddd' }}>Download</th>
    </tr>
  </thead>
  <tbody>
    {filteredData.map((row, index) => (
      <tr key={index} style={{ background: '#f4f4f4', textAlign: 'center' }}>
        <td style={{ padding: '10px', border: '1px solid #ddd' }}>
          <input
            type="checkbox"
            checked={selectedRows.includes(row.ID)}
            onChange={() => handleRowSelect(row.ID)}
          />
        </td>
        <td style={{ padding: '10px', border: '1px solid #ddd' }}>{row.ID}</td>
        <td style={{ padding: '10px', border: '1px solid #ddd' }}>{parseFloat(row['Custom Influence Score']).toFixed(2)}</td>
        <td style={{ padding: '10px', border: '1px solid #ddd' }}>{parseFloat(row.fraud_score_updated_normalized).toFixed(2)}</td>
        
        <td style={{ padding: '10px', border: '1px solid #ddd' }}>{parseFloat(row.profile_score_updated_normalized).toFixed(2)}</td>
        <td style={{ padding: '10px', border: '1px solid #ddd' }}>{parseFloat(row.updated_score).toFixed(2)}</td>
        <td style={{ padding: '10px', border: '1px solid #ddd' }}>{row.Domain}</td>
        <td style={{ padding: '10px', border: '1px solid #ddd' }}>
          <a href={`http://127.0.0.1:8000/myapp/download/${row.ID}`}>
            <i className="fas fa-download" style={{ fontSize: '20px', cursor: 'pointer' }}></i>
          </a>
        </td>
      </tr>
    ))}
  </tbody>
</table>

    </div>
  );
};

export default ProfileTable;
