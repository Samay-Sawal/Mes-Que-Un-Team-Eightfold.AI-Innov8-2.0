from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from .models import ResumeModel
import zipfile
import io

def download_resume(request, id):
    # Fetch the resume and LOR using the provided ID
    resume = get_object_or_404(ResumeModel, ID=id)
    
    # Create a BytesIO buffer to hold the zip data
    buffer = io.BytesIO()

    # Create a zip file in memory
    with zipfile.ZipFile(buffer, 'w') as z:
        # Add the resume file to the zip
        with resume.resume.open('rb') as resume_file:
            z.writestr(f'resume_{id}.pdf', resume_file.read())

        # Add the LOR file to the zip if it exists
        if resume.lor:
            with resume.lor.open('rb') as lor_file:
                z.writestr(f'lor_{id}.pdf', lor_file.read())

    # Set the pointer of the buffer to the beginning of the file
    buffer.seek(0)

    # Return the zip file as an HTTP response
    response = HttpResponse(buffer, content_type='application/zip')
    response['Content-Disposition'] = f'attachment; filename="files_{id}.zip"'
    
    return response