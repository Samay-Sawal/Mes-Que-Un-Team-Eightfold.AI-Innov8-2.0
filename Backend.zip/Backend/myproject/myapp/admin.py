from django.contrib import admin
from .models import *

admin.site.register(ResumeModel)
# Register your models here.
